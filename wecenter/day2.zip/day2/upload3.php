<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>
<?php
  if ($_FILES["file"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
    }
    $allowed_types = array('jpg', 'gif', 'png');
    $filename = $_FILES['file']['name'];
    #正则表达式匹配出上传文件的扩展名
    preg_match('|\.(\w+)$|', $filename, $ext);
    #print_r($ext);
    #转化成小写
    $ext = strtolower($ext[1]);
    #判断是否在被允许的扩展名里
    if(!in_array($ext, $allowed_types)){
     die('不被允许的文件类型,仅支持上传jpg,gif,png后缀的文件');
    }
  else
    {
      $folder = $_POST['dir'];
      echo "Upload: " . $_FILES["file"]["name"] . "<br />";
      echo "Type: " . $_FILES["file"]["type"] . "<br />";
      echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
      echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";

      if (file_exists(".".$folder . $_FILES["file"]["name"]))
        {
        echo $_FILES["file"]["name"] . " already exists. ";
        }
      else
        {
        move_uploaded_file($_FILES["file"]["tmp_name"], ".".$folder . $_FILES["file"]["name"]);
        echo "Stored in: " . $folder . $_FILES["file"]["name"];
        }
    }

?>
</html>