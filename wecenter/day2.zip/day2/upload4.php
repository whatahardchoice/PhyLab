﻿<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>
<?php
  if ($_FILES["file"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
    }
    $disallowed_types = array('php', 'php3', 'php4','asp','aspx','jsp','asa','cer');
    $filename = $_FILES['file']['name'];
    #正则表达式匹配出上传文件的扩展名
    preg_match('|\.(\w+)$|', $filename, $ext);
    #转化成小写
    $ext = strtolower($ext[1]);
    print_r($ext);
    #判断是否在被允许的扩展名里
    if(in_array($ext, $disallowed_types)){
     die('不被允许的文件类型,请重新选择正确的后缀类型');
    }
  else
    {
      echo "Upload: " . $_FILES["file"]["name"] . "<br />";
      echo "Type: " . $_FILES["file"]["type"] . "<br />";
      echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
      echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";

      if (0)
        {
        echo $_FILES["file"]["name"] . " already exists. ";
        }
      else
        {
        move_uploaded_file($_FILES["file"]["tmp_name"], "uploads/" . $_FILES["file"]["name"]);
        echo "Stored in: " . "/uploads/" . $_FILES["file"]["name"];
        }
    }

?>
</html>