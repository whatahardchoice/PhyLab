<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>
<?php
  if ($_FILES["file"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
    exit();
    }
    $filename = $_FILES['file']['name'];

    $filename = preg_replace("/php/", "", $filename);

      echo "Upload: " . $filename . "<br />";
      echo "Type: " . $_FILES["file"]["type"] . "<br />";
      echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
      echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";

      if (file_exists("uploads/". $_FILES["file"]["name"]))
        {
        echo $filename . " already exists. ";
        }
      else
        {
        move_uploaded_file($_FILES["file"]["tmp_name"], "uploads/" . $filename);
        echo "Stored in: " . "/uploads/" . $filename;
        }

?>
</html>