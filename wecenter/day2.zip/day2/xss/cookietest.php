<?php
setcookie("test","NormalCookie");
//设置HttpOnly属性
setcookie("important", "Security", NULL, NULL, NULL, NULL, TRUE); 

?>
