<?php session_start();?>
<?php
$uname = $_GET['username'];
$_SESSION['current-user'] = $uname;


echo "<h1>Current Session:</h1><br>";
echo 'current-user:        '.$_SESSION['current-user'] ;
?>
