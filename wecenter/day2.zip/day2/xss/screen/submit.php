<?php
$html_canvas = $_POST['pic'];
$image = base64_decode(substr($html_canvas, 22));
$a = file_put_contents('./test.jpg', $image);//返回的是字节数
print_r($a);
?>