<?php
/******************************************************************************
 *                        ��������:δ����Ʒ���Ա�                             *
 *                        ���ļ���:admin.php                                  *
 *                        �ļ�����:��������                                   *
 *                        ���򿪷�:δ��������http://www.qqwm.com              *
 *                        ��Ŀ����:����(wmweb@sohu.com)                       *
 * ע������:                                                                  *
 *         1)���ļ�л���޸ģ����ļ��д�����������ϵ��ʹ����û���޸�Ȩ         *
 * ��������:                                                                  *
 *         1)��������E-mail:qqwm@qqwm.com                                     *
 *         2)���紫��OICQ NO.:194088                                          *
 *         3)�칫�绰telephone:��ҵ�û���鿴������ϵ                         *
 *                                                                            *
 *      (http://www.qqwm.com)(http://ygy520.126.com)(http://wmnews.yeah.net)  *
 ******************************************************************************/
require_once('./global.php');
require_once(ROOT.'function/adminfunction.inc.php');
session_start();
error_reporting(7);
if(phpversion()>="4.1.0"){
	extract($_REQUEST);
}
$myfile="admin.php";
$nowtime=time();
$ip=ip();

if(trim($HTTP_POST_VARS['menu'])=="login"){
	$Log=$HTTP_POST_VARS['Log'];
	SaveLogin($Log);
	Foot();
exit;
}
if(trim($HTTP_GET_VARS['menu'])=="quitprecinct"){
	session_unregister("log_adminname");
	session_unregister("log_adminpass");
	session_unregister("log_intervaltime");
	session_destroy();
}
if((!isset($_SESSION['log_adminname']))||(!isset($_SESSION['log_adminpass']))||($_SESSION['log_adminname']!=$con['adminname'])||($_SESSION['log_adminpass']!=$con['adminpass'])){
	Head();
	ShowFormLogin();
	Foot();
exit;
}

$myfilemenu="admin";
$page=$HTTP_GET_VARS['page'];
if(!is_int($page)){$page=intval($page);}
if($page==""){$page=1;}

$HTTP_POST_VARS['menu'] = trim($HTTP_POST_VARS['menu']);
if($HTTP_POST_VARS['menu']=="savedata"){
	$username=$HTTP_POST_VARS[username];
	$useremail=$HTTP_POST_VARS[useremail];
	$useroicq=$HTTP_POST_VARS[useroicq];
	$userhomepage=$HTTP_POST_VARS[userhomepage];
	$usersex=$HTTP_POST_VARS[usersex];
	$headportrait=$HTTP_POST_VARS[headportrait];
	$posticon=$HTTP_POST_VARS[posticon];
	$content=$HTTP_POST_VARS[content];
	AddGuestContent($username,$useremail,$useroicq,$userhomepage,$usersex,$headportrait,$posticon,$content);
Foot();
exit;
}

Head();
Top();
switch($action){
	case "add";
		ShowFormAdd();
	break;
	case "search";
		$line = openfile($con[data_path].$con[data_name]);
		$HTTP_POST_VARS['keyword']=="" ? $keyword=$HTTP_GET_VARS['keyword'] : $keyword=$HTTP_POST_VARS['keyword'];
	
		for($W=1;$W<=count($line)-1;$W++){
			if($line[$W]=="") break;
			if (substr_count(@strip_tags($line[$W]),$keyword)!=0) {
				$searcharray[]=$line[$W];
			}
		}
		$j=0;$l=0;$nextint=0;
		$j = count($searcharray);
		$l = $j / $con[perpage];
		$nextint=ceil($l);
		ShowSearchList($page);
		PageLib($page);
	break;
	case "delete";
		$id=$HTTP_GET_VARS['id'];
		DelGuestContent($id);
	break;
	case "reply";
		$id=$HTTP_GET_VARS['id'];
		ShowFormReply($id);
	break;
	case "savereply";
		$replycontent=$HTTP_POST_VARS['replycontent'];
		$id=$HTTP_POST_VARS['id'];
		AddAnswer($id,$replycontent);
	break;
	case "censor";
		$id=$HTTP_GET_VARS['id'];
		DoCensor($id);
	break;
	case "editvariable";
		ShowFormSetup();
	break;
	case "savevariable";
		$Econ=$HTTP_POST_VARS['Econ'];
		SaveVariable($Econ);
	break;
	default:
		$line = openfile($con[data_path].$con[data_name]);
		$j=0;$l=0;$nextint=0;
		$j = count($line)-1;
		$l = $j / $con[perpage];
		$nextint=ceil($l);
		ShowContentList($page);
		PageLib($page);
}

Foot();
exit;
?>