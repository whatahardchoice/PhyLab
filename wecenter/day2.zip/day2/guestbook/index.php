<?php
/******************************************************************************
 *                        ��������:δ����Ʒ���Ա�                             *
 *                        ���ļ���:index.php                                  *
 *                        �ļ�����:���Ա���Ҫ�������                         *
 *                        ���򿪷�:δ��������http://www.qqwm.com              *
 *                        ��Ŀ����:����(wmweb@sohu.com)                       *
 * ע������:                                                                  *
 *         1)���ļ�л���޸ģ����ļ��д�����������ϵ��ʹ����û���޸�Ȩ         *
 * ��������:                                                                  *
 *         1)��������E-mail:qqwm@qqwm.com                                     *
 *         2)���紫��OICQ NO.:194088                                          *
 *         3)�칫�绰telephone:��ҵ�û���鿴������ϵ                         *
 *                                                                            *
 *      (http://www.qqwm.com)(http://ygy520.126.com)(http://wmnews.yeah.net)  *
 ******************************************************************************/
require_once('./global.php');
session_start();
error_reporting(7);
if(phpversion()>="4.1.0"){
	extract($_REQUEST);
}
$myfile="index.php";
$myfilemenu="index";
$page=$HTTP_GET_VARS['page'];
if(!is_int($page)){$page=intval($page);}
if($page==""){$page=1;}
$nowtime=time();
$ip=ip();
BadnessIp();

$HTTP_POST_VARS['menu'] = trim($HTTP_POST_VARS['menu']);
if($HTTP_POST_VARS['menu']=="savedata"){
	$username=$HTTP_POST_VARS[username];
	$useremail=$HTTP_POST_VARS[useremail];
	$useroicq=$HTTP_POST_VARS[useroicq];
	$userhomepage=$HTTP_POST_VARS[userhomepage];
	$usersex=$HTTP_POST_VARS[usersex];
	$headportrait=$HTTP_POST_VARS[headportrait];
	$posticon=$HTTP_POST_VARS[posticon];
	$content=$HTTP_POST_VARS[content];
	AddGuestContent($username,$useremail,$useroicq,$userhomepage,$usersex,$headportrait,$posticon,$content);
Foot();
exit;
}


Head();
Top();
switch($action){
	case "add";
		ShowFormAdd();
	break;
	case "search";
		$line = openfile($con[data_path].$con[data_name]);
		$HTTP_POST_VARS['keyword']=="" ? $keyword=$HTTP_GET_VARS['keyword'] : $keyword=$HTTP_POST_VARS['keyword'];
	
		for($W=1;$W<=count($line)-1;$W++){
			if($line[$W]=="") break;
			if (substr_count(@strip_tags($line[$W]),$keyword)!=0) {
				$searcharray[]=$line[$W];
			}
		}
		$j=0;$l=0;$nextint=0;
		$j = count($searcharray);
		$l = $j / $con[perpage];
		$nextint=ceil($l);
		if($con[post_position]=="1"){
			$con["post_terseness"] = "1";
			ShowFormAdd();
		}
		ShowSearchList($page);
		PageLib($page);
		if($con[post_position]=="2"){
			$con["post_terseness"] = "1";
			ShowFormAdd();
		}
	break;
	default:
		$line = openfile($con[data_path].$con[data_name]);
		$j=0;$l=0;$nextint=0;
		$j = count($line)-1;
		$l = $j / $con[perpage];
		$nextint=ceil($l);
		if($con[post_position]=="1"){
			$con["post_terseness"] = "1";
			ShowFormAdd();
		}
		ShowContentList($page);
		PageLib($page);
		if($con[post_position]=="2"){
			$con["post_terseness"] = "1";
			ShowFormAdd();
		}
}
Foot();
exit;
?>