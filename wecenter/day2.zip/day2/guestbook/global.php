<?php
/******************************************************************************
 *                        ��������:δ����Ʒ���Ա�                             *
 *                        ���ļ���:global.php                                 *
 *                        �ļ�����:��������                                   *
 *                        ���򿪷�:δ��������http://www.qqwm.com              *
 *                        ��Ŀ����:����(wmweb@sohu.com)                       *
 * ע������:                                                                  *
 *         1)���ļ�л���޸ģ����ļ��д�����������ϵ��ʹ����û���޸�Ȩ         *
 * ��������:                                                                  *
 *         1)��������E-mail:qqwm@qqwm.com                                     *
 *         2)���紫��OICQ NO.:194088                                          *
 *         3)�칫�绰telephone:��ҵ�û���鿴������ϵ                         *
 *                                                                            *
 *      (http://www.qqwm.com)(http://ygy520.126.com)(http://wmnews.yeah.net)  *
 ******************************************************************************/
set_magic_quotes_runtime(0);
session_cache_limiter('private, must-revalidate');
$server         = substr(getenv('SERVER_SOFTWARE'), 0, 3);
if ( function_exists('ini_get') ) {
	$onoff = ini_get('register_globals');
} else {
	$onoff = get_cfg_var('register_globals');
}
if ($onoff != 1) {
	@extract($HTTP_SERVER_VARS, EXTR_SKIP);
	@extract($HTTP_COOKIE_VARS, EXTR_SKIP);
	@extract($HTTP_POST_FILES, EXTR_SKIP);
	@extract($HTTP_POST_VARS, EXTR_SKIP);
	@extract($HTTP_GET_VARS, EXTR_SKIP);
	@extract($HTTP_ENV_VARS, EXTR_SKIP);
}
define('ROOT', './');
require ROOT.'function/config.inc.php';
require ROOT.'function/language.inc.php';
require ROOT.'function/validation.inc.php';
require ROOT.'function/function.inc.php';
$time=strftime("%Y-%m-%d %H:%M:%S",time()+$con[time_hour]*3600);
if ($HTTP_GET_VARS['HTTP_POST_VARS']['action'] == $HTTP_POST_VARS['action']) {
  unset($HTTP_POST_VARS['action']);
}
$HTTP_POST_VARS['action'] = trim($HTTP_POST_VARS['action']);

if ($HTTP_POST_VARS['action']) {
	$action = $HTTP_POST_VARS['action'];
} else if ($HTTP_GET_VARS['action']) {
	$action = $HTTP_GET_VARS['action'];
}
function iptype1 () { 
if (getenv("HTTP_CLIENT_IP")) { 
   return getenv("HTTP_CLIENT_IP"); 
} 
else { 
   return "none"; 
} 
} 
function iptype2 () { 
if (getenv("HTTP_X_FORWARDED_FOR")) { 
   return getenv("HTTP_X_FORWARDED_FOR"); 
} 
else { 
   return "none"; 
} 
} 
function iptype3 () { 
if (getenv("REMOTE_ADDR")) { 
   return getenv("REMOTE_ADDR"); 
} 
else { 
   return "none"; 
} 
} 
function ip() { 
$ip1 = iptype1(); 
$ip2 = iptype2(); 
$ip3 = iptype3(); 
if (isset($ip1) && $ip1 != "none" && $ip1 != "unknown") { 
   return $ip1; 
} 
elseif (isset($ip2) && $ip2 != "none" && $ip2 != "unknown") { 
   return $ip2; 
} 
elseif (isset($ip3) && $ip3 != "none" && $ip3 != "unknown") { 
   return $ip3; 
}   
  else { 
  return "none"; 
} 
}
function readover($filename,$method="rb"){
	if($handle=@fopen($filename,$method)){
		flock($handle,LOCK_SH);
		$filedata=fread($handle,filesize($filename));
		fclose($handle);
	}
	return $filedata;
}
function writeover($filename,$data,$method="rb+",$iflock=1){
	touch($filename);
	$handle=fopen($filename,$method);
	if($iflock){
		flock($handle,LOCK_EX);
	}
	fputs($handle,$data);
	if($method=="rb+") ftruncate($handle,strlen($data));
	fclose($handle);
}
function openfile($filename){
	$filedata=readover($filename);
	$filedata=str_replace("\n","\n<:qqwm:>",$filedata);
	$filedb=explode("<:qqwm:>",$filedata);
	$count=count($filedb);
	if($filedb[$count-1]==''||$filedb[$count-1]=="\r"){unset($filedb[$count-1]);}
	$filedb[0]="";
	return $filedb;
}
function WM_htmlspecialchars($msg,$trim=0,$br3=0) {
    $msg = str_replace("&","&amp;",$msg);
	$msg = str_replace("<","&lt;",$msg);
    $msg = str_replace(">","&gt;",$msg);
	$msg = str_replace(" ", "&nbsp;", $msg);
	$msg = str_replace( "\r\n",  "\n", $msg);
	$msg = str_replace( "\r",  "", $msg);
	if($br3==0){$msg = ereg_replace("\n((��| )*\n){3,}","\n",$msg);}
	$msg = str_replace("\n",  "<br />", $msg);
	$msg = str_replace(",", "&#44;", $msg);
	$msg = str_replace("%", "&#37;", $msg);
	$msg=preg_replace("/\\\\t/is","\wsm",$msg);
	$msg=preg_replace("/\\t/is"," ",$msg);
	if($trim){
		$msg = trim($msg);
	}

	return $msg;
}
function errorview($error_a,$error_b,$error_c=3){
	global $con,$lang,$myfile;
	include($con[theme_path].$con[template].'/errorview.html');
	Foot();
exit;
}

function SucceedRegister($succeed_msg,$succeed_fromurl){
	global $con,$lang,$myfile;
	include($con[theme_path].$con[template].'/succeed.html');
	Foot();
exit;
}

















?>