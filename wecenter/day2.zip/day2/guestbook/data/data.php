<?php die('NOT FOR YOUR EYES, SIR.'); ?>
