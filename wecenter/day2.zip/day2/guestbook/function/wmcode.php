<?php
basename(__FILE__) == basename($PHP_SELF) ? die('wmcode.php, contains all functions for <a href="http://www.qqwm.com/">www.qqwm.com</a>. <h2><a href="index.php">Local guestbook is here</a></h2>') : '';
/******************************************************************************
 *                        ��������:δ����Ʒ���Ա�                             *
 *                        ���ļ���:wmcode.php                                 *
 *                        �ļ�����:����ת�������⣬��Ҫ����WM2HTML            *
 *                        ���򿪷�:δ��������http://www.qqwm.com              *
 *                        ��Ŀ����:����(wmweb@sohu.com)                       *
 * ע������:                                                                  *
 *         1)���ļ�л���޸ģ����ļ��д�����������ϵ��ʹ����û���޸�Ȩ         *
 * ��������:                                                                  *
 *         1)��������E-mail:qqwm@qqwm.com                                     *
 *         2)���紫��OICQ NO.:194088                                          *
 *         3)�칫�绰telephone:��ҵ�û���鿴������ϵ                         *
 *                                                                            *
 *      (http://www.qqwm.com)(http://ygy520.126.com)(http://wmnews.yeah.net)  *
 ******************************************************************************/
function Convert($message) 
{
	global $con,$lang,$myfile;
	$message=ereg_replace("\|","��",$message);
	$message=preg_replace("/\wsm/is",'\t',$message);
	$message = str_replace("&#44;", "\,", $message);
	$message=stripslashes($message);
	if ($con[if_img]==1){
		$message = preg_replace("/\[img\](.+?)\[\/img\]/is","<a href=\"\\1\" target=\"_blank\"><img src=\"\\1\" border=\"0\" onload=\"javascript:if(this.width>screen.width-".$con[bigimgwidth].")this.width=screen.width-".$con[bigimgwidth]."\" /></a>",$message);
    }else{
		$message = preg_replace("/(\[img\])(\S+?)(\[\/img\])/is","<img src='".$con[img_url]."/code/img.gif' align='absbottom'> <a target=_blank href='\\2'>images: \\2</a>",$message);
	}
	if ($con[if_flash]==1){
        $message = preg_replace("/(\[flash=)(\S+?)(\,)(\S+?)(\])(\S+?)(\[\/flash\])/is","<OBJECT CLASSID=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" WIDTH=\\2 HEIGHT=\\4><PARAM NAME=MOVIE VALUE=\\6><PARAM NAME=PLAY VALUE=TRUE><PARAM NAME=LOOP VALUE=TRUE><PARAM NAME=QUALITY VALUE=HIGH><EMBED SRC=\\6 WIDTH=\\2 HEIGHT=\\4 PLAY=TRUE LOOP=TRUE QUALITY=HIGH></EMBED></OBJECT><br />[<a target=_blank href=\\6>".$lang[template][c0004]."</a>] ",$message);
	}else{
		$message = preg_replace("/(\[flash=)(\S+?)(\,)(\S+?)(\])(\S+?)(\[\/flash\])/is","<img src='".$con[img_url]."/code/flash.gif' align='absbottom'> <a target=_blank href=\\6>flash: \\6</a>",$message);
	}
	
	$codearray=array(
		'[code]'=>"[\tcode\t]",
		'[/code]'=>"[\t/code\t]",
		'[quote]'=>"[\tquote\t]",
		'[/quote]'=>"[\t/quote\t]",
		'[php]'=>"[\tphp\t]",
		'[/php]'=>"[\t/php\t]",
	);

	if (strpos($message,"[code]") !== false && strpos($message,"[/code]") !== false){ 
		$message=preg_replace("/\[code\](.+?)\[\/code\]/eis","txtcode('\\1')",$message);
	}

	if (strpos($message,"[quote]") !== false && strpos($message,"[/quote]") !== false){ 
		$message=preg_replace("/\[quote\](.+?)\[\/quote\]/eis","qoute('\\1')",$message);
	}
	if (strpos($message,"[php]") !== false && strpos($message,"[/php]") !== false){ 
		$message=preg_replace("/\[php\](.+?)\[\/php\]/eis","phpcode('\\1')",$message);
	}
	$message =str_replace("[u]","<u>",$message);
	$message =str_replace("[/u]","</u>",$message);
	$message =str_replace("[b]","<strong>",$message);
	$message =str_replace("[/b]","</strong>",$message);
	$message =str_replace("[i]","<em>",$message);
	$message =str_replace("[/i]","</em>",$message);
	$message =str_replace("[list]","<ul>",$message);
	$message =str_replace('[list=1]', '<ol type=1>', $message);
	$message =str_replace('[list=a]', '<ol type=a>', $message);
	$message =str_replace('[list=A]', '<ol type=A>', $message);
	$message =str_replace('[*]', '<li>', $message);
	$message =str_replace("[/list]","</ul>",$message);
	$searcharray = array(
		"/\[font=([^\[]*)\](.+?)\[\/font\]/is",
		"/\[color=([#0-9a-z]{1,10})\](.+?)\[\/color\]/is",
		"/\[email=([^\[]*)\](.+?)\[\/email\]/is",
	    "/\[email\]([^\[]*)\[\/email\]/is",
		"/\[size=([^\[]*)\](.+?)\[\/size\]/is",
		"/(\[fly\])(.+?)(\[\/fly\])/is",
		"/(\[move\])(.+?)(\[\/move\])/is",
		"/(\[align=)(left|center|right)(\])(.+?)(\[\/align\])/is",
		"/(\[glow=)(\S+?)(\,)(.+?)(\,)(.+?)(\])(.+?)(\[\/glow\])/is",
		"/\[shadow=(\S+?)\,(.+?)\,(.+?)\](.+?)\[\/shadow\]/is"
	);
	$replacearray = array(
		"<font face=\"\\1\">\\2</font>",
		"<font color=\"\\1\">\\2</font>",
		"<a href=\"mailto:\\1\">\\2</a>",
		"<a href=\"mailto:\\1\">\\1</a>",
		"<font size=\"\\1\">\\2</font>",
		"<marquee width=90% behavior=alternate scrollamount=3>\\2</marquee>",
		"<marquee scrollamount=3>\\2</marquee>",
		"<DIV Align=\"\\2\">\\4</DIV>",
		"<table width=\"\\2\" style=\"filter:glow(color=\\4, strength=\\6)\"><tr><td>\\8</td></tr></table>",
		"<table width=\"\\1\" style=\"filter:shadow(color=\\2, direction=\\3)\"><tr><td>\\4</td></tr></table>"
	);
	$message=preg_replace($searcharray,$replacearray,$message);

	if($con[if_mpeg]==1){
		$message = preg_replace("/\[wmv\]\s*(\S+?)\s*\[\/wmv\]/is","<EMBED src=\\1 HEIGHT=\"256\" WIDTH=\"314\" AutoStart=1></EMBED>",$message);
		$message = preg_replace("/\[rm\]\s*(\S+?)\s*\[\/rm\]/is","<object classid=clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA height=241 id=Player width=316 VIEWASTEXT><param name=\"_ExtentX\" value=\"12726\"><param name=\"_ExtentY\" value=\"8520\"><param name=\"AUTOSTART\" value=\"0\"><param name=\"SHUFFLE\" value=\"0\"><param name=\"PREFETCH\" value=\"0\"><param name=\"NOLABELS\" value=\"0\"><param name=\"CONTROLS\" value=\"ImageWindow\"><param name=\"CONSOLE\" value=\"_master\"><param name=\"LOOP\" value=\"0\"><param name=\"NUMLOOP\" value=\"0\"><param name=\"CENTER\" value=\"0\"><param name=\"MAINTAINASPECT\" value=\"\\1\"><param name=\"BACKGROUNDCOLOR\" value=\"#000000\"></object><br><object classid=clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA height=32 id=Player width=316 VIEWASTEXT><param name=\"_ExtentX\" value=\"18256\"><param name=\"_ExtentY\" value=\"794\"><param name=\"AUTOSTART\" value=\"1\"><param name=\"SHUFFLE\" value=\"0\"><param name=\"PREFETCH\" value=\"0\"><param name=\"NOLABELS\" value=\"0\"><param name=\"CONTROLS\" value=\"controlpanel\"><param name=\"CONSOLE\" value=\"_master\"><param name=\"LOOP\" value=\"0\"><param name=\"NUMLOOP\" value=\"0\"><param name=\"CENTER\" value=\"0\"><param name=\"MAINTAINASPECT\" value=\"0\"><param name=\"BACKGROUNDCOLOR\" value=\"#000000\"><param name=\"SRC\" value=\"\\1\"></object>",$message);
	}else{
		$message = preg_replace("/(\[wmv\])(\S+?)(\[\/wmv\])/is","<img src='".$con[img_url]."/code/mpg.gif' align='absbottom'> <a target=_blank href='\\2'>\\2</a>",$message);
		$message = preg_replace("/(\[rm\])(\S+?)(\[\/rm\])/is","<img src='".$con[img_url]."/code/ra.gif' align='absbottom'> <a target=_blank href='\\2'>\\2</a>",$message);
	}
	if ($con[if_iframe]==1) {
		$message = preg_replace("/\[iframe\]\s*(\S+?)\s*\[\/iframe\]/is","<IFRAME SRC=\\1 FRAMEBORDER=0 ALLOWTRANSPARENCY=true SCROLLING=YES WIDTH=97% HEIGHT=340></IFRAME>",$message);
	}else{
		$message = preg_replace("/(\[iframe\])(\S+?)(\[\/iframe\])/is",$lang[template][c0001]." <a target=_blank href='\\2'>\\2</a>",$message);
	}

	if(strpos($message,'[/URL]')!==false || strpos($message,'[/url]')!==false){
		$searcharray = array(
			"/\[url=(https?|ftp|gopher|news|telnet|mms|rtsp)([^\[]*)\](.+?)\[\/url\]/is",			
			"/\[url\]www\.([^\[]*)\[\/url\]/is",
			"/\[url\](https?|ftp|gopher|news|telnet|mms|rtsp)([^\[]*)\[\/url\]/is"
		);
		$replacearray = array(
			"<a href=\\1\\2 target=_blank>\\3</a>",
			"<a href=\"http://www.\\1\" target=_blank>www.\\1</a>",
			"<a href='\\1\\2' target=_blank>\\1\\2</a>"
		); 
		$message=preg_replace($searcharray,$replacearray,$message);
	}
	foreach($codearray as $key=>$value){
		$message=str_replace($value,$key,$message);
	}
	return $message;
}
function qoute($code){
	global $codearray;
	global $con,$lang;
	$code="<table width=\"96%\"  border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"1\" bgcolor=\"#000000\"><tr><td bgcolor=\"#E0E7ED\">$code</td></tr></table>";
	return $code;
}

function txtcode($code){
	global $codearray;
	global $con,$lang;
	$code = stripslashes($code);
	$code = str_replace("<br />", "</li><li>", $code);
	$code="<div style=\"margin-bottom:2px\">".$lang[template][c0002]."</div><div style=\"margin:0px; padding:6px; border:1px inset; width:$con[codewidth]; height:$con[codeheight]; overflow:auto\"><code style=\"white-space:nowrap\"><code><ol><li>".$code."</li></ol></code></code></div></div>";
	return $code;
}
function phpcode($code) {
	global $codearray;
	global $con,$lang;

  if (floor(phpversion())<4) {
    $buffer=$code;
  } else {
		$code = str_replace("&#44;", "\,", $code);
		$code = str_replace("&#37;", "%", $code);
		$code = str_replace("&nbsp;", " ", $code);
		$code = str_replace("<br>", "\n", $code);
		$code = str_replace("<br />", "\n", $code);
		$code = str_replace("&gt;", ">", $code);
		$code = str_replace("&lt;", "<", $code);
		$code = str_replace("&amp;", "&", $code);
		$code = str_replace('$', '\$', $code);
		$code = str_replace('\n', '\\\\n', $code);
		$code = str_replace('\r', '\\\\r', $code);
		$code = stripslashes($code);

		if (!strpos($code,"<?") and substr($code,0,2)!="<?") {
			$code="<?\n".trim($code)."\n?>";
			$addedtags=1;
		}
		ob_start();
		$oldlevel=error_reporting(0);
		highlight_string($code);
		error_reporting($oldlevel);
		$buffer = ob_get_contents();
		ob_end_clean();
		if ($addedtags) {
		  $openingpos = strpos($buffer,'&lt;?');
		  $closingpos = strrpos($buffer, '?');
		  $buffer=substr($buffer, 0, $openingpos).substr($buffer, $openingpos+5, $closingpos-($openingpos+5)).substr($buffer, $closingpos+5);
		}
		$buffer = str_replace("&quot;", "\"", $buffer);
  }
return "<div style=\"margin-bottom:2px\">".$lang[template][c0003]."</div><div style=\"margin:0px; padding:6px; border:1px inset; width:$con[codewidth]; height:$con[codeheight]; overflow:auto\"><code style=\"white-space:nowrap\"><code>".$buffer."</code></code></div></div>";
}
?>