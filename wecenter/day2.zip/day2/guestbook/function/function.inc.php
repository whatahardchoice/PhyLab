<?php
basename(__FILE__) == basename($PHP_SELF) ? die('function.inc.php, contains all functions for <a href="http://www.qqwm.com/">www.qqwm.com</a>. <h2><a href="index.php">Local guestbook is here</a></h2>') : '';
/******************************************************************************
 *                        ��������:δ����Ʒ���Ա�                             *
 *                        ���ļ���:function.inc.php                           *
 *                        �ļ�����:��������                                   *
 *                        ���򿪷�:δ��������http://www.qqwm.com              *
 *                        ��Ŀ����:����(wmweb@sohu.com)                       *
 * ע������:                                                                  *
 *         1)���ļ�л���޸ģ����ļ��д�����������ϵ��ʹ����û���޸�Ȩ         *
 * ��������:                                                                  *
 *         1)��������E-mail:qqwm@qqwm.com                                     *
 *         2)���紫��OICQ NO.:194088                                          *
 *         3)�칫�绰telephone:��ҵ�û���鿴������ϵ                         *
 *                                                                            *
 *      (http://www.qqwm.com)(http://ygy520.126.com)(http://wmnews.yeah.net)  *
 ******************************************************************************/
function BadnessIp(){
	global $con,$lang,$ip;
	$badnessip_array = explode("|",$con[badness_ip]);
	for($i = 0; $i < count($badnessip_array); $i++){
		if($badnessip_array[$i]=="") continue;
		if($ip==$badnessip_array[$i]){
			Head();Top();errorview($lang[error][generic],$lang[error][e0013]);exit;
			break;
		}
	}

}

function AddGuestContent($username="",$useremail="",$useroicq="",$userhomepage="",$usersex=0,$headportrait,$posticon="00.gif",$content=""){
	global $con,$lang,$myfile;
	global $time,$ip,$nowtime;
	global $myfilemenu;
	if($myfilemenu!="admin"){
		if(isset($_SESSION['myintervaltime'])){
			if($nowtime - $_SESSION['myintervaltime'] < $con['post_interval']){Head();Top();errorview($lang[error][generic],$lang[error][e0014]);exit;}
		}
	}
	if($username != ""){
		$username=WM_htmlspecialchars($username);
		if(strlen($username) > 15){Head();Top();errorview($lang[error][generic],$lang[error][e0002]);exit;}
		$reserve_array = explode(",",$con[reserve_name]);
		$n=0;
		while($n<=sizeof($reserve_array)) {
			if($username==$reserve_array[$n]){Head();Top();errorview($lang[error][generic],$lang[error][e0003]);exit;}
			$n++;
		}
		$bad_array = explode(",",$con[filtratemsg]);
		$m=0;
		while($m<sizeof($bad_array)) {
			$username = eregi_replace($bad_array[$m],  "��", $username);
			$m++;
		}
	}else{Head();Top();errorview($lang[error][generic],$lang[error][e0004]);exit;}
	if($useremail != ""){
		$useremail=WM_htmlspecialchars($useremail,1,1);
		if(!IsEmailAddress($useremail)){Head();Top();errorview($lang[error][generic],$lang[error][e0005]);exit;}
	}
	if($useroicq != ""){
		$useroicq=WM_htmlspecialchars($useroicq,1,1);
		if(strlen($useroicq) > 10){Head();Top();errorview($lang[error][generic],$lang[error][e0009]);exit;}
		if(!IsDigit($useroicq)){Head();Top();errorview($lang[error][generic],$lang[error][e0011]);exit;}
	}
	if($userhomepage != ""){
		$userhomepage=WM_htmlspecialchars($userhomepage,1,1);
		if(!IsUrl($userhomepage)){Head();Top();errorview($lang[error][generic],$lang[error][e0012]);exit;}
		$userhomepage=ereg_replace("http://","",$userhomepage);
	}
	if($content != ""){
		$contentlen=$con[content_len];
		if(!is_int($contentlen)){$contentlen=intval($contentlen);}
		if(strlen($content) > $contentlen){Head();Top();errorview($lang[error][generic],$lang[error][e0006]);exit;}
		$bad_array = explode(",",$con[filtratemsg]);
		$i=0;
		while($i<sizeof($bad_array)) {
			$content = eregi_replace( $bad_array[$i],  "��", $content);
			$i++;
		}
		//$content=WM_htmlspecialchars($content);
	}else{Head();Top();errorview($lang[error][generic],$lang[error][e0007]);exit;}
	if($posticon==""){$posticon="00.gif";}
	$posticon=WM_htmlspecialchars($posticon,1,1);
	$usersex=WM_htmlspecialchars($usersex,1,1);
	$headportrait=WM_htmlspecialchars($headportrait,1,1);
	
	$line = openfile($con[data_path].$con[data_name]);
	list($lno,$ltime) = explode("\t", $line[1]);
	$no=$lno+1;
	if($con[censor]==1){$censor=0;}else{$censor=1;}
	$title="";#����
	$newline = $no."\t".$time."\t".$username."\t".$useremail."\t".$useroicq."\t".$userhomepage."\t".$usersex."\t".$headportrait."\t".$posticon."\t".$ip."\t".$censor."\t".$title."\t".$content."\n";
	$indata="";
	$indata="<?php die('NOT FOR YOUR EYES, SIR.'); ?>\n".$newline.implode('', $line);
	writeover($con[data_path].$con[data_name],$indata);
	session_register("myintervaltime");
	$_SESSION["myintervaltime"] = time();
	Head();Top();
	SucceedRegister($lang[msg][s0001],$myfile);

}

function ShowContentList($page){
	global $con,$lang,$myfile;
	global $line,$nextint;
	global $myfilemenu;
	$imgurl="$con[img_url]";
	include(ROOT.'function/wmcode.php');
	if(!isset($page)) {$page=1; $nextint=1;}
	if(($page>$nextint)||($page<=0)){$page=1;};
	$star = ($page - 1) * $con[perpage] + 1;
	$end= $star - 1 + $con[perpage];

	for($i = $star; $i <= $end; $i++){
		if($line[$i]=="") break;
		list($sno,$stime,$sname,$semail,$soicq,$shomepage,$ssex,$sportrait,$sicon,$sip,$scensor,$stitle,$scontent,$sanswer) = explode("\t", $line[$i]);
		switch($ssex){
			case "1";
			$user="<font color=\"$con[nameclor_male]\"> $sname </font>";
			break;
			case "2";
			$user="<font color=\"$con[nameclor_feminie]\"> $sname </font>";
			break;
			default:
			$user="<font color=\"$con[nameclor_default]\"> $sname </font>";
		}
		if($shomepage != ""){
			$outhp="<a href=\"http://".$shomepage."\" target=\"_blank\"><img src=\"$con[img_url]/homepage.gif\" width=\"16\" height=\"16\" border=\"0\" /></a>";
		}else{
			$outhp="<img src=\"$con[img_url]/homepage.gif\" width=\"16\" height=\"16\" border=\"0\" />";
		}
		if($soicq != ""){
			$outoicq="<a href=\"http://friend.qq.com/cgi-bin/friend/user_show_info?ln=".$soicq."\" target=\"_blank\"><img src=\"$con[img_url]/oicq.gif\" width=\"16\" height=\"16\" border=\"0\" /></a>";
		}else{
			$outoicq="<img src=\"$con[img_url]/oicq2.gif\" width=\"16\" height=\"16\" border=\"0\" />";
		}
		if($semail != ""){
			$outmail="<a href=\"mailto:$semail\"><img src=\"$con[img_url]/email.gif\" width=\"16\" height=\"16\" border=\"0\" /></a>";
		}else{
			$outmail="<img src=\"$con[img_url]/email.gif\" width=\"16\" height=\"16\" border=\"0\" />";
		}
		$myfilemenu == "admin" ? $outip="<img src=\"$con[img_url]/ip.gif\" width=\"16\" height=\"15\" alt=\"$sip\" border=\"0\" />" : $outip="<img src=\"$con[img_url]/ip.gif\" width=\"16\" height=\"15\" />";
		$scontent = str_replace("\n",  "", $scontent);
		if($scensor!=1){
			$myfilemenu == "admin" ? $scontent=$lang[msg][e0010]."<br />".Convert($scontent) : $scontent=$lang[msg][e0009];
		}else{$scontent=Convert($scontent);}
		$sanswer = str_replace("\n",  "", $sanswer);
		if($sanswer!=""){
			list($answer_msg,$answer_time) = explode(",", $sanswer);
			$answer_msg=Convert($answer_msg);
			$show_answer = "<hr width=\"100%\" size=\"1\" color=\"#B9C4CC\" noshade=\"noshade\" />".$lang[msg][e0004]."<br />$answer_msg<br /><font color=\"#B9C4CC\"><em>".$lang[msg][e0005].$answer_time."</em></font>";
		}else{$show_answer = "";}
		$myfilemenu == "admin" ? $admin_menu='<a href="'.$myfile.'?action=reply&id='.$sno.'"><img src="'.$con[img_url].'/reply.gif" width="18" height="18" border="0" /></a><a href="'.$myfile.'?action=modify&id='.$sno.'"><img src="'.$con[img_url].'/edit.gif" width="18" height="18" border="0" /></a><a href="'.$myfile.'?action=censor&id='.$sno.'"><img src="'.$con[img_url].'/censor.gif" width="18" height="18" border="0" /></a><a href="javascript:delete_confirm('.$sno.');"><img src="'.$con[img_url].'/del.gif" width="18" height="18" border="0" /></a>' : $admin_menu="";
		
		include($con[theme_path].$con[template].'/list.html');
		
	}
	
}

function ShowSearchList($page){
	global $con,$lang,$myfile;
	global $searcharray,$nextint;
	global $myfilemenu;

	$imgurl="$con[img_url]";
	include(ROOT.'function/wmcode.php');
	if(!isset($page)) {$page=1; $nextint=1;}
	if(($page>$nextint)||($page<=0)){$page=1;};
	$star = ($page - 1) * $con[perpage] + 1;
	$end= $star - 1 + $con[perpage];

	for($i = $star-1; $i < $end; $i++){
		if($searcharray[$i]=="") break;
		list($sno,$stime,$sname,$semail,$soicq,$shomepage,$ssex,$sportrait,$sicon,$sip,$scensor,$stitle,$scontent,$sanswer) = explode("\t", $searcharray[$i]);
		switch($ssex){
			case "1";
			$user="<font color=\"$con[nameclor_male]\"> $sname </font>";
			break;
			case "2";
			$user="<font color=\"$con[nameclor_feminie]\"> $sname </font>";
			break;
			default:
			$user="<font color=\"$con[nameclor_default]\"> $sname </font>";
		}
		if($shomepage != ""){
			$outhp="<a href=\"http://".$shomepage."\" target=\"_blank\"><img src=\"$con[img_url]/homepage.gif\" width=\"16\" height=\"16\" border=\"0\" /></a>";
		}else{
			$outhp="<img src=\"$con[img_url]/homepage.gif\" width=\"16\" height=\"16\" border=\"0\" />";
		}
		if($soicq != ""){
			$outoicq="<a href=\"http://friend.qq.com/cgi-bin/friend/user_show_info?ln=".$soicq."\" target=\"_blank\"><img src=\"$con[img_url]/oicq.gif\" width=\"16\" height=\"16\" border=\"0\" /></a>";
		}else{
			$outoicq="<img src=\"$con[img_url]/oicq2.gif\" width=\"16\" height=\"16\" border=\"0\" />";
		}
		if($semail != ""){
			$outmail="<a href=\"mailto:$semail\"><img src=\"$con[img_url]/email.gif\" width=\"16\" height=\"16\" border=\"0\" /></a>";
		}else{
			$outmail="<img src=\"$con[img_url]/email.gif\" width=\"16\" height=\"16\" border=\"0\" />";
		}
		$myfilemenu == "admin" ? $outip="<img src=\"$con[img_url]/ip.gif\" width=\"16\" height=\"15\" alt=\"$sip\" border=\"0\" />" : $outip="<img src=\"$con[img_url]/ip.gif\" width=\"16\" height=\"15\" />";
		$scontent = str_replace("\n",  "", $scontent);
		if($scensor!=1){
			$myfilemenu == "admin" ? $scontent=$lang[msg][e0010]."<br />".Convert($scontent) : $scontent=$lang[msg][e0009];
		}else{$scontent=Convert($scontent);}
		$sanswer = str_replace("\n",  "", $sanswer);
		if($sanswer!=""){
			list($answer_msg,$answer_time) = explode(",", $sanswer);
			$answer_msg=Convert($answer_msg);
			$show_answer = "<hr width=\"100%\" size=\"1\" color=\"#B9C4CC\" noshade=\"noshade\" />".$lang[msg][e0004]."<br />$answer_msg<br /><font color=\"#B9C4CC\"><em>".$lang[msg][e0005].$answer_time."</em></font>";
		}else{$show_answer = "";}
		$myfilemenu == "admin" ? $admin_menu='<a href="'.$myfile.'?action=reply&id='.$sno.'"><img src="'.$con[img_url].'/reply.gif" width="18" height="18" border="0" /></a><a href="'.$myfile.'?action=modify&id='.$sno.'"><img src="'.$con[img_url].'/edit.gif" width="18" height="18" border="0" /></a><a href="'.$myfile.'?action=censor&id='.$sno.'"><img src="'.$con[img_url].'/censor.gif" width="18" height="18" border="0" /></a><a href="javascript:delete_confirm('.$sno.');"><img src="'.$con[img_url].'/del.gif" width="18" height="18" border="0" /></a>' : $admin_menu="";
		
		include($con[theme_path].$con[template].'/list.html');
		
	}
	
}

function PageLib($page){
	global $con,$lang,$myfile;
	global $nextint,$keyword,$action;
	if(isset($page)){
		if (($page==1)&&($nextint==0)){
		}else{
			if(($page>$nextint)||($page<=0)){$page=1;};
		}
	}else {
		$page=1;
	}
	if($nextint==1){
		$show_page = "&nbsp;<strong>[1]</strong>&nbsp;";
	}else{
		$show_page .= "<a href=\"".$myfile."?keyword=".$keyword."&action=".$action."&page=1\">".$lang[template][p0001]."</a>&nbsp";
		if($nextint>6){
			if(($page>3)&&($page+3<$nextint)){
				$page_a=$page;
				$page_b=$page_a+3;
				for($i=$page_a-2;$i<$page_b;$i++){
					if($i==$page){
						$show_page .= "<strong>[$page]</strong>&nbsp";
					}else {
						$show_page .= "<a href=\"".$myfile."?keyword=".$keyword."&action=".$action."&page=$i\">[$i]</a>&nbsp";
					}
				}
				$show_page .= "...&nbsp;<a href=\"".$myfile."?keyword=".$keyword."&action=".$action."&page=$nextint\">[$nextint]</a>&nbsp";
			}
			if($page<4){
				for($k=1;$k<6;$k++){
					if($k==$page){
						$show_page .= "<strong>[$page]</strong>&nbsp";
					}else {
						$show_page .= "<a href=\"".$myfile."?keyword=".$keyword."&action=".$action."&page=$k\">[$k]</a>&nbsp";
					}
				}
				$show_page .= "...&nbsp;<a href=\"".$myfile."?keyword=".$keyword."&action=".$action."&page=$nextint\">[$nextint]</a>&nbsp";
			}
			if($page+3>=$nextint){
				for($m=$nextint-4;$m<$nextint+1;$m++){
					if($m==$page){
						$show_page .= "<strong>[$page]</strong>&nbsp";
					}else {
						$show_page .= "<a href=\"".$myfile."?keyword=".$keyword."&action=".$action."&page=$m\">[$m]</a>&nbsp";
					}
				}
			}
		}else {
			for($n=1;$n<$nextint+1;$n++){
				if($n==$page){
					$show_page .= "<strong>[$page]</strong>&nbsp";
				}else{
					$show_page .= "<a href=\"".$myfile."?keyword=".$keyword."&action=".$action."&page=$n\">[$n]</a>&nbsp";
				}
			}
		}
		$show_page .= "<a href=\"".$myfile."?keyword=".$keyword."&action=".$action."&page=$nextint\">".$lang[template][p0002]."</a>";
	}
include($con[theme_path].$con[template].'/page.html');
}

function Head() {
	global $con,$lang,$myfile;
	global $myfilemenu;
	$myfilemenu == "admin" ? $delvalidatejs="<script language=\"JavaScript\">\n function delete_confirm(aaa){\n question = confirm(\"".$lang[msg][e0008]."\")\n if (question != \"0\"){ window: location=\"".$myfile."?action=delete&id=\"+aaa;\n}\n}\n</script>" : $delvalidatejs='';
	include_once($con['theme_path'].$con['template'].'/head.html');
}

function Top() {
	global $con,$lang,$myfile;
	global $myfilemenu;
	include($con[theme_path].$con[template].'/top.html');
}

function Foot() {
	global $con,$lang,$myfile;
	include($con[theme_path].$con[template].'/foot.html');
}

function ShowFormAdd() {
	global $con,$lang,$myfile;
	include($con[theme_path].$con[template].'/post_form.html');
}

?>