<?php
basename(__FILE__) == basename($PHP_SELF) ? die('adminfunction.inc.php, contains all functions for <a href="http://www.qqwm.com/">www.qqwm.com</a>. <h2><a href="index.php">Local guestbook is here</a></h2>') : '';
/******************************************************************************
 *                        ��������:δ����Ʒ���Ա�                             *
 *                        ���ļ���:adminfunction.inc.php                      *
 *                        �ļ�����:�����������ú�����                         *
 *                        ���򿪷�:δ��������http://www.qqwm.com              *
 *                        ��Ŀ����:����(wmweb@sohu.com)                       *
 * ע������:                                                                  *
 *         1)���ļ�л���޸ģ����ļ��д�����������ϵ��ʹ����û���޸�Ȩ         *
 * ��������:                                                                  *
 *         1)��������E-mail:qqwm@qqwm.com                                     *
 *         2)���紫��OICQ NO.:194088                                          *
 *         3)�칫�绰telephone:��ҵ�û���鿴������ϵ                         *
 *                                                                            *
 *      (http://www.qqwm.com)(http://ygy520.126.com)(http://wmnews.yeah.net)  *
 ******************************************************************************/
function DelGuestContent($id){
	global $con,$lang,$myfile;
	$line = openfile($con[data_path].$con[data_name]);
	for($i = 1; $i <= count($line); $i++){
		$find = FALSE;
		if($line[$i]=="") continue;
		list($dno,$dtime) = explode("\t",$line[$i]);
		if($id==$dno){
			$line[$i]="";
			$find = TRUE;
			break;
		}
	}
	if($find){
		writeover($con[data_path].$con[data_name],"<?php die('NOT FOR YOUR EYES, SIR.'); ?>\n".implode('', $line));
	}
	SucceedRegister($lang[template][a0003],$myfile);
	exit;
}

function AddAnswer($id,$answer_content){
	global $con,$lang;
	global $myfile,$time;
	$answer_content=WM_htmlspecialchars($answer_content);
	$line = openfile($con[data_path].$con[data_name]);
	for($i=1;$i<=count($line);$i++){
		if($line[$i]=="") continue;
		list($ano,$atime,$aname,$aemail,$aoicq,$ahomepage,$asex,$aportrait,$aicon,$aip,$acensor,$atitle,$acontent,$aanswer)=explode("\t", $line[$i]);
		$find = FALSE;
		if($id==$ano){
			$find = TRUE;
			if(strlen($aip)<6) {$aip="0";}
			$acontent = str_replace("\n",  "", $acontent);
			$aanswer = str_replace("\n",  "", $aanswer);
			$aanswer=$answer_content.",".$time;
			$line[$i]=$ano."\t".$atime."\t".$aname."\t".$aemail."\t".$aoicq."\t".$ahomepage."\t".$asex."\t".$aportrait."\t".$aicon."\t".$aip."\t".$acensor."\t".$atitle."\t".$acontent."\t".$aanswer."\n";
			break;
		}
	}
	if($find){
		writeover($con[data_path].$con[data_name],"<?php die('NOT FOR YOUR EYES, SIR.'); ?>\n".implode('', $line));
	}
	SucceedRegister($lang[template][a0004],$myfile);
	exit;
}

function DoCensor($id){
	global $con,$lang,$myfile;
	$line = openfile($con[data_path].$con[data_name]);
	for($i=1;$i<=count($line);$i++){
		if($line[$i]=="") continue;
		list($cno,$ctime,$cname,$cemail,$coicq,$chomepage,$csex,$cportrait,$cicon,$cip,$ccensor,$ctitle,$ccontent,$canswer)=explode("\t", $line[$i]);
		$find = FALSE;
		if($id==$cno){
			$find = TRUE;
			$ccontent = str_replace("\n",  "", $ccontent);
			$canswer = str_replace("\n",  "", $canswer);
			$line[$i]=$cno."\t".$ctime."\t".$cname."\t".$cemail."\t".$coicq."\t".$chomepage."\t".$csex."\t".$cportrait."\t".$cicon."\t".$cip."\t1\t".$ctitle."\t".$ccontent."\t".$canswer."\n";
			break;
		}
	}
	if($find){
		writeover($con[data_path].$con[data_name],"<?php die('NOT FOR YOUR EYES, SIR.'); ?>\n".implode('', $line));
	}
	SucceedRegister($lang[template][a0005],$myfile);
	exit;
}

function ShowFormReply($id) {
	global $con,$lang,$myfile;
	include($con[theme_path].$con[template].'/reply.html');
}

function ShowFormLogin(){
	global $con,$lang,$myfile;
	include($con[theme_path].$con[template].'/login.html');
}

function SaveLogin($Log){
	global $con,$lang,$myfile;
	global $time,$ip,$nowtime;
	if(isset($_SESSION['log_intervaltime'])){
		if($nowtime - $_SESSION['log_intervaltime'] < 10){Head();errorview($lang[error][generic],$lang[template][a0068]);exit;}
	}
	$Log=WM_htmlspecialchars_B($Log);
	if(($Log['adminname']=="")||($Log['adminpass']=="")||($Log['adminname']!=$con['adminname'])||($Log['adminpass']!=$con['adminpass'])){
		if(($Log['adminname']!="")&&($Log['adminpass']!="")){
			session_register("log_intervaltime");
			$_SESSION["log_intervaltime"] = time();
		}
		Head();
		ShowFormLogin();
		Foot();
exit;
	}else{
		session_register("log_adminname");
		$_SESSION["log_adminname"] = $Log['adminname'];
		session_register("log_adminpass");
		$_SESSION["log_adminpass"] = $Log['adminpass'];
		
		Head();
		SucceedRegister($lang[template][a0069],$myfile,1);
		Foot();
		exit;
	}

}

function ShowFormSetup() {
	global $con,$lang,$myfile;
	$fg=opendir('./templates/');
	$outtemplatesdir="";
	while ($thistemplates=readdir($fg)) {
		if (($thistemplates!='.')&&($thistemplates!='..')) {
			$outtemplatesdir.="<option value=\"".$thistemplates."\">".$thistemplates."</option>";
		}
	}closedir($fg);
	include($con[theme_path].$con[template].'/variable.html');
}

function SaveVariable($Econ){
	global $con,$lang,$myfile;
	$Econ=WM_htmlspecialchars_B($Econ);
	if($Econ[data_name]!=$con[data_name]){
		@rename($con[data_path].$con[data_name], $con[data_path].$Econ[data_name])||errorview($lang[error][system],$lang[template][a0060],20);
	}
	foreach($Econ as $key=>$element){
		$INcon[]="\$con[\"$key\"]=\"$element\";\n";
	}
	@chmod("./function/config.inc.php", 0666 );
	writeover("./function/config.inc.php","<?php\n".implode('', $INcon)."\$con[\"data_path\"]=\"./data/\";\n\$con[\"theme_path\"]=\"./templates/\";\n\$con[\"img_url\"]=\"".$Econ['imgdir']."/".$Econ['template']."\";\n?>");
	SucceedRegister($lang[template][a0059],$myfile."?action=editvariable");
	exit;
}
function WM_htmlspecialchars_B($msgarray){
	if (is_array($msgarray)){
		foreach($msgarray as $key=>$element){
			//$msgarray[$key] = str_replace("<","&lt;",$element);
			//$msgarray[$key] = str_replace(">","&gt;",$msgarray[$key]);
		}
	}
return $msgarray;
}
?>