<?php
setcookie("language","chinese");
?>