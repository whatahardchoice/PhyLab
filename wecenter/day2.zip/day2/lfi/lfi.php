<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>
<?php
if( !ini_get('display_errors') ) {
  ini_set('display_errors', 'On');
  }
error_reporting(E_ALL);

$lan = $_COOKIE['language'];
if(!$lan)
{
	setcookie("language","chinese");
	include("chinese.php");
}
else
{
	include($lan.".php");
}

?>
</html>