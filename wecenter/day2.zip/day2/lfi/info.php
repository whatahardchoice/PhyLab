<?php
 phpinfo();
sleep(10);
 ?>